[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/vjaHVsrO)
# Object-oriented Programming in Python for Mathematicians

## Chapter 3 Exercises

Refer to the [exercise instructions](https://object-oriented-python.github.io/3_objects.html#exercises).

These tests are for exercises 3.3 - 3.6. The tests build sequentially, so by exercise 3.6, all tests should pass with a correct implementation.
